LOG_FILE_NAME = "log.txt"
SUCESS_FILE_NAME = "success.txt"